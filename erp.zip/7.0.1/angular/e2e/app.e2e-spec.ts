import { erpTemplatePage } from './app.po';

describe('erp App', function() {
  let page: erpTemplatePage;

  beforeEach(() => {
    page = new erpTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
